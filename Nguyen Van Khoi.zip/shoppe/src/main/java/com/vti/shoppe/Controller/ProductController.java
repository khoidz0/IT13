package com.vti.shoppe.Controller;


import com.vti.shoppe.Model.Product;
import com.vti.shoppe.Model.ProductRepository;
import com.vti.shoppe.Sevice.ProductSevice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(path  = "/api/v1/Products")
public class ProductController {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductSevice productSevice;

    @PostMapping("/insert")
    List<Product> insert (Product newProduct){
       List<Product> productList = new ArrayList<>();
       productList = productSevice.insertProduct(newProduct);
        return productList;
    }

    @GetMapping("/name")
    List<Product> searchStudentByName(@RequestParam String name) {
        List<Product> studentList = productSevice.searchProductByName(name);
        return studentList;
    }


}

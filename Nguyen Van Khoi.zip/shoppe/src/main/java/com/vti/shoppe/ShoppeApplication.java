package com.vti.shoppe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppeApplication.class, args);
	}

}

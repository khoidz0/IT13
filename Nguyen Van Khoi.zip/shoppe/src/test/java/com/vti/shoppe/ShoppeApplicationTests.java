package com.vti.shoppe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppeApplicationTests {

	@Test
	void contextLoads() {
	}

}

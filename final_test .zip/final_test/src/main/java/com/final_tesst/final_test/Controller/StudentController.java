package com.final_tesst.final_test.Controller;


import com.final_tesst.final_test.Model.ResponseObject;
import com.final_tesst.final_test.Model.Student;
import com.final_tesst.final_test.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path  = "/api/v1/students")
public class StudentController {
    @Autowired
    private StudentRepository studentRepository;

    @GetMapping("")
    ResponseEntity<ResponseObject> getAllStudent()
    {
        List<Student> StudentList = studentRepository.findAll();
        return ResponseEntity.status(HttpStatus.OK).
                body(new ResponseObject("ok" , "successfully" , StudentList));
    }
    @PostMapping({"/insert"})
        ResponseEntity<ResponseObject> insertStudent(@RequestBody Student newStudent)
             {
                     List<Student> foundStudent = studentRepository.findByIdNumber(newStudent.getIdNumber());
                     if (foundStudent.size()>0)
                     {
                                 return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(
                                 new ResponseObject("ok","Student IdNumber aldready taken","")
                            );
                     }
                     Student returnStudent = studentRepository.save(newStudent);
                                return ResponseEntity.status(HttpStatus.OK).body(
                                        new ResponseObject("ok" ,"insert sucessfully",returnStudent)
                                );


             }

    @DeleteMapping("/{id}")
    ResponseEntity<ResponseObject> deleteStudent(@PathVariable Long id)
    {
        Optional<Student> foundStudent = studentRepository.findById(id);
        if(foundStudent.isPresent()){
            studentRepository.deleteById(id);
            return  ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("ok","success", foundStudent.get() ));
        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok","student not found", "" ));
    }

    @GetMapping("/{id}")
    ResponseEntity<ResponseObject> getStudentInfo(@PathVariable Long id)
    {
        Optional<Student> foundStudent = studentRepository.findById(id);
        if(foundStudent.isPresent()){
            return  ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("ok","success", foundStudent.get() ));

        }
        return  ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok","Student not found", "" ));
    }

}

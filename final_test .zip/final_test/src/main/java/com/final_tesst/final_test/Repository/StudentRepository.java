package com.final_tesst.final_test.Repository;

import com.final_tesst.final_test.Model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student , Long> {
    List<Student> findByIdNumber(String idNumber);


}
